# Animação Algoritmo de Ordenação

  Essa animação simples é feita em HTML, CSS e JS.
  
  Integrantes: Joao Victor Cesa, Guilherme Almeida, Joao Pedro Oliveira, Victor Alves, Marcos Vinicius, Alexandre

- Quicksort:  

   É um algoritmo de ordenação que segue o princípio de dividir para conquistar. Nele um elemento pivô é escolhido para servir como o foco e os elementos ao seu redor são ordenados de forma que o pivô esteja na sua posição final; 

   Para tal é necessário particionar os elementos em grupos menores para oredená-los;

   Neste exemplo o último elemento da direita servirá como pivô. 
